# Wurzburg UI Style Kit

本壓縮包彙整 CLI Proxy API 官方介面的**樣式原始檔**（樣式表、主題 token、字體宣告、授權與 commit），供 IP 管理系統套用同一套視覺風格。檔案均自上游倉庫原樣複製，未改內容。

完整設計說明（配色表、版型、元件、與 IP 管理畫面的對應）見同目錄：

- [CLIProxyAPI-UI-style-reference.md](./CLIProxyAPI-UI-style-reference.md)

官方截圖（取自 EasyCLIProxyAPI README 簡中版）：

- `easycliproxyapi-01-home-dashboard.png`（首頁儀表板）
- `easycliproxyapi-02-api-providers.png`（API 接入列表）
- `easycliproxyapi-03-usage-analytics.png`（使用記錄總覽）

**建議主風格：EasyCLIProxyAPI 預設淺色主題（`light`）**——純白工作區、冷灰側欄、近黑主按鈕（`#222222`）、大量留白。Management Center 的暖灰紙感、純白與深色主題可作為可切換的替代方案。

本套件打包日期：2026-11-12（Asia/Taipei）。兩套上游皆為 **MIT License**（Copyright (c) 2026 Router-For.ME），屬於寬鬆授權；重製或改作時請保留各資料夾內的 `LICENSE` 與版權聲明。

兩套倉庫都**沒有** Tailwind / PostCSS 設定，也**沒有**隨倉庫發佈的字型檔（`.woff` / `.ttf` 等）。字體是在 CSS／SCSS 裡用系統字族宣告。

---

## 1. management-center／

來源：https://github.com/router-for-me/Cli-Proxy-API-Management-Center  
Commit：`953fb2444350c6c36052dda46cac0abce6b23ea6`（短碼 `953fb24`）  
提交時間：2026-11-05 20:16:05 +0800（Asia/Taipei）  
授權：MIT，見 `management-center/LICENSE`  
Commit 紀錄：`management-center/COMMIT.txt`

內容（保留原倉庫相對路徑）：

- 全部 `src/**/*.scss`（92 個），含全域樣式與各頁／元件的 SCSS Modules
- 主題狀態：`src/stores/useThemeStore.ts`（`light` / `white` / `dark` / `auto`，寫入 `data-theme`）

未納入：應用程式邏輯（`.tsx` 頁面、API、測試）與建置設定。上游沒有 Tailwind／PostCSS 設定，也沒有打包字型檔。

### 色彩、主題、字體要看哪些檔

| 用途 | 檔案 |
| --- | --- |
| 色彩 token（淺色暖灰、純白、深色三套主題） | `src/styles/themes.scss` |
| 間距、圓角、陰影、字族變數 | `src/styles/variables.scss` |
| 重設與全域（含 `font-family`、捲軸、頁面底色） | `src/styles/reset.scss`、`src/styles/global.scss` |
| 按鈕、輸入、卡片、徽章、對話框 | `src/styles/components.scss` |
| 側欄、頂欄、內容區版型 | `src/styles/layout.scss` |
| Mixin、斷點 | `src/styles/mixins.scss` |
| 登入頁調色盤 | `src/pages/login/_palette.scss` |
| 表格／表單／開關／Sheet 等元件 | `src/components/ui/**/*.scss` |
| 主題切換邏輯 | `src/stores/useThemeStore.ts` |

字族宣告在 `src/styles/variables.scss`（系統無襯線 + 等寬備援），沒有下載網型。

---

## 2. easycliproxyapi／

來源：https://github.com/router-for-me/EasyCLIProxyAPI  
Commit：`97a7d9b76b2462a15076ebaab1719b996885af5d`（短碼 `97a7d9b`）  
提交時間：2026-11-11 17:05:24 +0800（Asia/Taipei）  
授權：MIT，見 `easycliproxyapi/LICENSE`  
Commit 紀錄：`easycliproxyapi/COMMIT.txt`

內容（保留原倉庫相對路徑）：

- 全部正式樣式 `src/**/*.css`（62 個；不含 `src/mocks/` 與測試夾）
- 主題模組 `src/themes/*.ts`（17 個，含 `light`、`dark`、`warmSand`、`graphite`、`midnight`、`sakura`、`anime` 與套用／契約程式）
- 主題執行層：`src/theme.ts`、`src/themeController.ts`
- 自訂主題 JSON schema：`theme.schema.json`
- 自訂主題說明與範例：`docs/themes/custom-theme-guide.md`、`docs/themes/custom-theme.example.json`

未納入：頁面與元件的 TSX 邏輯、偏好設定存檔、Tauri／Rust、測試、以及 `src/mocks/` 的模擬樣式。上游沒有 Tailwind／PostCSS 設定，也沒有打包字型檔。

### 色彩、主題、字體要看哪些檔

| 用途 | 檔案 |
| --- | --- |
| **預設淺色／深色語意色（建議作為主風格）** | `src/styles/tokens/semantic.css` |
| 字級、字重、行高、圓角、陰影、動效 | `src/styles/tokens/base.css`、`src/styles/tokens/components.css` |
| Token 匯入入口 | `src/styles/tokens/index.css` |
| 字族宣告（含繁中 `zh-TW`：Noto Sans TC／PingFang TC／微軟正黑體） | `src/styles.css`（檔案前段 `:root` / `:root:lang(zh-TW)`） |
| 樣式層與匯入順序 | `src/styles/index.css`、`src/styles/layers.css` |
| 側欄、表面、搜尋、表單控件 | `src/styles/sidebar.css`、`src/styles/surfaces.css`、`src/styles/search-controls.css`、`src/styles/select-controls.css` |
| 預設 `light` / `dark` 主題定義 | `src/themes/light.ts`、`src/themes/dark.ts` |
| 可選「暖沙」紙感主題 | `src/themes/warmSand.ts` |
| 其他內建主題 | `src/themes/graphite.ts`、`midnight.ts`、`sakura.ts`、`anime.ts` |
| Token 契約與套用 | `src/themes/tokenContract.ts`、`src/themes/applyTheme.ts`、`src/themes/registry.ts` |
| 自訂主題格式 | `theme.schema.json`、`docs/themes/` |

預設主題 id 為 `light`（視窗背景 `#ffffff`，強調色 `#222222`）。這是官方 README 截圖所呈現的外觀，也是本套件建議 IP 管理系統採用的主主題。

---

## 3. 目錄結構（根層）

```
Wurzburg-UI-Style-Kit/
├── README.md
├── CLIProxyAPI-UI-style-reference.md
├── easycliproxyapi-01-home-dashboard.png
├── easycliproxyapi-02-api-providers.png
├── easycliproxyapi-03-usage-analytics.png
├── management-center/
│   ├── LICENSE
│   ├── COMMIT.txt
│   └── src/…
└── easycliproxyapi/
    ├── LICENSE
    ├── COMMIT.txt
    ├── theme.schema.json
    ├── docs/themes/…
    └── src/…
```

使用或再散布這些上游檔案時，請一併保留對應的 MIT `LICENSE`。設計決策與畫面映射請以 `CLIProxyAPI-UI-style-reference.md` 為準。
