# CLI Proxy API UI 風格設計參考

> 用途：供 UI 設計 Bot 實作，或直接貼入 IP 管理系統 PRD 的 UI 章節。  
> 對象產品：從核心交換器 ARP table 納管 IP 的管理系統。  
> 研究日期：2026-11-11（Asia/Taipei）。  
> 原則：**色碼只寫進原始碼或可對應回原始碼的值**；從官方截圖量到、但原始碼沒有寫死的顏色，一律標「截圖取樣／推測」。不要自行發明色碼。

---

## 1. 來源與範圍

Jeff 希望新的 IP 管理系統「套用 CLI Proxy API 的 UI 風格」。官方其實有兩套密切相關的介面，風格相近、細節不同，必須分開引用，不能混成同一套 token。

| 專案 | 角色 | 倉庫 | 本文件如何使用 |
| --- | --- | --- | --- |
| CLIProxyAPI | 後端代理本體，本身幾乎沒有管理介面 | https://github.com/router-for-me/CLIProxyAPI | 產品脈絡；不作為視覺來源 |
| Cli-Proxy-API-Management-Center | 官方 Web 管理中心（單檔 `management.html`） | https://github.com/router-for-me/Cli-Proxy-API-Management-Center | **Web 面板的設計 token 主來源**（SCSS 變數、版型、元件） |
| EasyCLIProxyAPI | 官方桌面控制台（Tauri + React） | https://github.com/router-for-me/EasyCLIProxyAPI | **官方 README 截圖**與更完整的視覺語言（預設淺色主題） |

抽樣版本：

- Management Center：`main` commit `953fb24`（2026-11-05 20:16 Asia/Taipei）。README 沒有介面截圖。
- EasyCLIProxyAPI：`main` commit `97a7d9b`（2026-11-11 17:05 Asia/Taipei），README 附五張 1396×900 官方截圖。

**給 IP 管理系統的建議（可寫進 PRD）：**  
視覺上以 EasyCLIProxyAPI **預設淺色主題**為主風格——純白工作區、冷灰側欄、近黑主按鈕、大量留白、KPI 卡片與膠囊篩選。這是官方公開截圖所呈現、也最接近「介面很好看」的那套樣子。  
Management Center 的「極簡暖灰／紙感」淺色、純白主題與暖色深色，作為可切換的官方替代主題保留，尤其適合偏維運、長時間盯盤的場景。

官方說明頁：https://help.router-for.me/management/webui（Web UI）、https://help.router-for.me/cn/management/gui（桌面客戶端）。

---

## 2. 技術棧（來源：各倉庫 package.json / README）

### 2.1 Management Center（Web）

- React 19、TypeScript、Vite 8、Zustand、Axios、React Router 7
- 樣式：**SCSS Modules**（不是 Tailwind、也不是現成的 Ant Design / shadcn / MUI）
- 動效：Motion
- 編輯器：CodeMirror 6（YAML）
- 國際化：i18next（含繁體中文 `zh-TW`）
- 圖示：自製 inline SVG，路徑來自 **Lucide**（ISC；註解寫明為了單檔／離線而不直接依賴 `lucide-react`）
- 建置：Bun 1.4.3，輸出單一 HTML

### 2.2 EasyCLIProxyAPI（桌面）

- Tauri 2、React 19、TypeScript、Vite 6、**lucide-react**
- 樣式：原生 CSS + 設計 token（`src/styles/tokens/`），同樣**不是 Tailwind**
- 內建主題：`light`、`dark`、`warm-sand-light`、`graphite`、`midnight`、`sakura`、`anime`，另可自訂主題 JSON
- 預設主題 id：`light`（純白＋近黑強調色）

IP 管理系統不需要複製這兩套技術棧，但元件與 token 應對齊它們的視覺契約，而不是另找一套通用後台框架的預設外觀。

---

## 3. 色彩系統

### 3.1 Management Center：三套主題（來源：`src/styles/themes.scss`、`src/styles/variables.scss`）

主題切換為 `light`（預設，無 `data-theme`）、`white`、`dark`、`auto`。`auto` 在深色系統下套用 `dark`，在淺色系統下套用 **`white`（純白）**，不是暖灰 `light`。

共用語意色（淺色／純白／深色多數相同）：

| Token | 色碼 | 用途 |
| --- | --- | --- |
| `--primary-color` / `$primary-color` | `#8b8680` | 行動主色（暖灰褐，不是藍色） |
| `--primary-hover`（淺／白） | `#7f7a74` | 主色懸停 |
| `--primary-active`（淺／白） | `#726d67` | 主色按下 |
| `--primary-hover`（深） | `#9a948e` | 深色主色懸停 |
| `--primary-active`（深） | `#a6a099` | 深色主色按下 |
| `--primary-contrast` | `#ffffff` | 主按鈕文字 |
| `--success-color` / `$success-color` | `#10b981` | 成功／「活的流量」 |
| `--warning-color` / `--error-color` / `$error-color` | `#c65746` | 警告與錯誤共用（赤陶紅） |
| `--quota-medium-color`（淺／白） | `#e0aa14` | 配額中段 |
| `--quota-medium-color`（深） | `#ffd862` | 配額中段（深色） |
| `--amber-color`（淺／白） | `#d97706` | 工作臺警示 |
| `--amber-text`（淺／白） | `#92400e` | 琥珀文字 |
| `--amber-color`（深） | `#f59e0b` | 工作臺警示（深色） |
| `--amber-text`（深） | `#fcd34d` | 琥珀文字（深色） |
| `--viz-success`（淺／白） | `#10b981` | 視覺化成功 |
| `--viz-success`（深） | `#0fae78` | 視覺化成功（深色降一檔） |
| `--viz-failure`（淺／白） | `#c65746` | 視覺化失敗 |
| `--viz-failure`（深） | `#cf4b3a` | 視覺化失敗（深色） |

**淺色（極簡暖灰／紙感）` :root `：**

| Token | 色碼 |
| --- | --- |
| `--bg-secondary` 頁面背景 | `#faf9f5` |
| `--bg-primary` 容器／卡片 | `#f0eee8` |
| `--bg-tertiary` hover／次級 | `#e9e6df` |
| `--bg-quinary` | `#f6f4ee` |
| `--floating-surface` | `#fffdf9` |
| `--text-primary` | `#2d2a26` |
| `--text-secondary` | `#6d6760` |
| `--text-tertiary` / `--text-muted` | `#a29c95` |
| `--text-quaternary` | `#c0bab3` |
| `--border-color` | `#e3e1db` |
| `--border-primary` | `#d5d2cb` |
| `--border-hover` | `#cecac4` |
| `--success-badge-bg` / `text` / `border` | `#d1fae5` / `#065f46` / `#6ee7b7` |
| `--failure-badge-bg` / `text` | `rgba(198, 87, 70, 0.14)` / `#8a3a30` |
| `--shadow` | `0 1px 2px 0 rgb(0 0 0 / 0.08)` |
| `--shadow-lg` | `0 10px 18px -3px rgb(0 0 0 / 0.1)` |
| `--floating-shadow` | `0 12px 26px rgba(0, 0, 0, 0.14)` |

**純白 `[data-theme='white']`：** 頁面與卡片皆 `#ffffff`；次級背景 `#f6f6f6`；邊框 `#e5e5e5` / `#d9d9d9` / `#cccccc`。文字與主色與淺色主題相同。

**深色 `[data-theme='dark']`：**

| Token | 色碼 |
| --- | --- |
| `--bg-secondary` 頁面 | `#151412` |
| `--bg-primary` 卡片 | `#1d1b18` |
| `--bg-tertiary` | `#262320` |
| `--bg-hover` | `#2e2a26` |
| `--bg-quinary` | `#191714` |
| `--floating-surface` | `#2a2723` |
| `--text-primary` | `#f6f4f1` |
| `--text-secondary` | `#c9c3bb` |
| `--text-tertiary` | `#9c958d` |
| `--text-quaternary` | `#6f6962` |
| `--border-color` | `#3a3530` |
| `--border-primary` | `#4a453f` |
| `--border-hover` | `#5a544d` |
| `--warning-text`（深色） | `#f1b0a6` |
| `--success-badge-bg` / `text` / `border` | `rgba(6, 78, 59, 0.3)` / `#6ee7b7` / `#059669` |
| `--shadow` | `0 1px 3px 0 rgb(0 0 0 / 0.3)` |
| `--floating-shadow` | `0 14px 30px rgba(0, 0, 0, 0.4)` |

圓角 token：`--radius-md: 8px`（主題檔）以及 SCSS `$radius-sm: 4px`、`$radius-md: 8px`、`$radius-lg: 12px`、`$radius-full: 9999px`。

毛玻璃：`--glass-blur: 12px`；`--glass-bg` 為主背景 82% 透明混合。在 `max-width: 768px`、`prefers-reduced-motion` 或 `prefers-reduced-transparency` 時關閉 blur。

原始碼註解強調：**翡翠綠只表達「活的流量」**，不要拿來當普通裝飾色。

### 3.2 EasyCLIProxyAPI 預設淺色／深色（來源：`src/styles/tokens/semantic.css`、`src/themes/light.ts`、`dark.ts`）

這套是官方截圖的主題。強調色是**近黑**，不是 Management Center 的暖灰褐，也不是品牌藍。

**淺色（預設 `light`，視窗背景 `#ffffff`）：**

| Token | 色碼 | 用途 |
| --- | --- | --- |
| `--color-workspace` / `--color-surface` / `--color-surface-sunken` | `#ffffff` | 工作區、卡片、沉陷面 |
| `--color-surface-subtle` | `#eff3f0` | 微弱底（略帶綠灰） |
| `--color-surface-hover` | `#f6f8f6` | 懸停 |
| `--color-surface-active` | `#f0f0f0` | 按下 |
| `--color-text-primary` | `#0f172a` | 主文字（slate-900） |
| `--color-text-secondary` | `#1e293b` | 次文字 |
| `--color-text-tertiary` | `#334155` | 第三級 |
| `--color-text-muted` | `#475569` | 弱化 |
| `--color-text-disabled` | `#64748b` | 停用 |
| `--color-text-on-accent` | `#ffffff` | 主按鈕文字 |
| `--color-text-link` / `--color-accent` | `#222222` | 連結與強調 |
| `--color-accent-strong` | `#000000` | 強調加深 |
| `--color-accent-soft` | `#f0f0f0` | 強調淺底 |
| `--color-border-subtle` | `#f1f5f9` | 極淡邊框 |
| `--color-border-default` | `#e2e8f0` | 預設邊框 |
| `--color-border-strong` | `#cbd5e1` | 強邊框 |
| `--color-border-hover` | `#94a3b8` | 邊框懸停 |
| `--color-border-focus` | `#222222` | 焦點邊框 |
| `--color-success` / `--color-success-text` | `#2f6b3f` | 成功（偏低飽和綠，不是霓虹） |
| `--color-success-subtle` / `border` | `#eef7f0` / `#b6d3bd` | 成功底／邊 |
| `--color-warning` | `#c77b30` | 警告 |
| `--color-warning-subtle` / `border` / `text` | `#fff7e9` / `#dfbf91` / `#8b5b21` | 警告組合 |
| `--color-danger` / `--color-danger-text` | `#9f2d20` | 危險 |
| `--color-danger-subtle` / `border` | `#fff1ee` / `#dfb7b0` | 危險組合 |
| `--color-info` | `#0f766e` | 資訊（teal-600） |
| `--button-danger-soft-bg` / `border` / `text` | `#fff1f2` / `#fecdd3` / `#e11d48` | 柔和危險鈕（如「停止」） |
| `--status-dot-success-bg` | `#10b981` | 狀態圓點 |
| `--state-pill-success-bg` / `text` / `border` | `#f0fdf4` / `#15803d` / `#bbf7d0` | 成功膠囊 |
| `--usage-tone-speed` / `tokens` / `success` / `cache` | `#007aff` / `#5856d6` / `#34c759` / `#ff9500` | 分析數字／圖表色（偏 iOS 系統色） |

主題預覽程式對淺色側欄的後備值為 `#f7f8fa`（`src/themes/registry.ts` 的 `themePreview`）。官方首頁截圖側欄取樣亦為 `#f7f8fa`，與這個後備值一致。

**深色（`dark`，視窗背景 `#0b0d11`）：**

| Token | 色碼 |
| --- | --- |
| `--color-workspace` / sunken | `#0b0d11` |
| `--color-surface` | `#141720` |
| `--color-surface-subtle` | `#1c212c` |
| `--color-surface-hover` / `active` | `#252b38` / `#2e3646` |
| `--color-text-primary` | `#f8fafc` |
| `--color-text-secondary` | `#d3dce8` |
| `--color-text-tertiary` | `#b0bdcf` |
| `--color-text-muted` | `#9aa9bf` |
| `--color-accent` | `#f5f5f5` |
| `--color-accent-strong` | `#ffffff` |
| `--color-text-on-accent` | `#0b0d11` |
| `--color-text-link` / `--color-info` | `#60a5fa` |
| `--color-border-default` / `subtle` | `#222836` |
| `--color-border-strong` / `hover` | `#2e3646` / `#3a4356` |
| `--color-success` / `--color-success-text` | `#34d399` / `#6ee7b7` |
| `--color-warning` / `--color-warning-text` | `#d97706` / `#fcd34d` |
| `--color-danger` | `#c65746` |
| `--color-danger-text` | `#fca5a5` |

陰影（`src/styles/tokens/base.css`，淺色）：

- `--shadow-xs`: `0 1px 2px rgba(24, 32, 42, 0.04)`
- `--shadow-sm`: `0 1px 3px rgba(24, 32, 42, 0.06), 0 1px 2px rgba(24, 32, 42, 0.03)`
- `--shadow-md`: `0 4px 12px -2px rgba(24, 32, 42, 0.08), 0 2px 4px rgba(24, 32, 42, 0.04)`
- `--shadow-lg`: `0 12px 32px -6px rgba(24, 32, 42, 0.12), 0 4px 8px -2px rgba(24, 32, 42, 0.06)`
- `--shadow-panel`: `0 1px 3px 0 rgba(15, 23, 42, 0.05), 0 1px 2px -1px rgba(15, 23, 42, 0.03)`

圓角與 Management Center 相同：4 / 8 / 12 / 9999px。

### 3.3 EasyCLIProxyAPI「暖沙」可選主題（來源：`src/themes/warmSand.ts`）

若產品想更接近 Management Center 的紙感，官方已有現成配方，不要自行調色：

| Token | 色碼 |
| --- | --- |
| 視窗／工作區 | `#F7F3EC` |
| 表面 | `#FFFCF7` |
| 柔和表面 | `#F1EBE2` |
| 懸停 | `#ECE3D7` |
| 主／次／弱文字 | `#352F2A` / `#5B5148` / `#6E6258` |
| 邊框／淡／強／懸停 | `#D6C9B9` / `#E8DED1` / `#BEAD98` / `#98836D` |
| 強調／加深／淺底 | `#945632` / `#7B4326` / `#F2E3D4` |
| 側欄背景／文字 | `#EFE7DC` / `#51473F` |
| 側欄選中底／邊 | `#F2E3D4` / `#D7BDA4` |

### 3.4 截圖取樣（推測，僅供核對）

從官方簡中截圖 `zh-CN/1.png`、`zh-CN/3.png` 量到、用來核對原始碼的值：

- 側欄背景 `#f7f8fa`（與 `themePreview` 後備值相同，可當正式側欄色使用）
- 工作區／卡片內部 `#ffffff`
- 側欄與工作區交界（截圖取樣）約 `#e7e9eb`，接近原始碼 `--color-border-default: #e2e8f0`，**實作請用原始碼值**
- 「停止」柔和危險鈕邊框 `#fecdd3`（與 `--button-danger-soft-border` 相同）
- 「+ 新增 API Key」主按鈕 `#222222`（與 `--color-accent` 相同）

分析頁數字的藍／紫／綠／橙，請用 3.2 節的 `--usage-tone-*`，不要用截圖抗鋸齒後的近似色。

---

## 4. 版面結構

### 4.1 EasyCLIProxyAPI（官方截圖所見，建議作為 IP 系統主版型）

來源：`src/styles.css`、`src/styles/sidebar.css`，並對照 README 截圖。

- **左固定側欄 + 右內容區** 兩欄網格：`grid-template-columns: var(--app-sidebar-width) minmax(0, 1fr)`
- 側欄寬 **264px**（較窄視窗降為 **232px**；更窄時可收成 **64px** 圖示軌）
- 側欄背景淺冷灰，選中項目是**白底圓角膠囊**，不是色塊高亮
- 側欄上段：品牌標（圓角小 logo + 產品名 + 一行副標「桌面控制台」）
- 側欄中段：導覽清單，可有巢狀群組（例如「外掛」可展開）
- 側欄下段：次要入口（新手模式、聯繫我們）＋**語言**與**外觀／主題**
- **沒有傳統頂部導覽列**。頁面標題、篩選與操作直接放在內容區頂部
- 內容區是純白，卡片像輕輕浮在畫布上，陰影極淡、主要靠 1px 邊框分層
- **密度偏低、留白大**：KPI 列、雙欄卡片、圖表區之間都有明確間距，不走資訊密集的傳統網管風格
- 首頁：頂部一列 4 張等寬指標卡 → 下方兩欄狀態／連線卡
- 使用記錄：頂部子頁籤（總覽／分析／明細…）→ 一排膠囊篩選器 → 6 張 KPI → 左長條圖＋右甜甜圈與摘要卡
- 列表頁：頂部廠商／分類 **分段頁籤**（icon + 名稱 + 計數）→ 工具列（搜尋、次要按鈕、實心主按鈕）→ 單列資源卡

響應式：側欄可收合；內容網格在窄螢幕改單欄（使用記錄圖表區亦然）。

### 4.2 Management Center（Web 面板版型）

來源：`src/styles/layout.scss`、`src/features/dashboard/dashboard.module.scss`。

- 左固定側欄 **216px**，收合 **60px**；行動版改 overlay，寬 `min(280px, 100vw - 24px)`
- 側欄按群組分節：操作／閘道／觀測／控制，群組標籤 10px、字距較開
- **浮動頂部操作列**（主題、語言等）位於內容區右上，按鈕 38×38px、圓角 11px，外層容器圓角 16px；可用毛玻璃
- 側欄與內容交界有 24×24、圓角 14px 的浮動收合鈕
- 主內容 padding：`70px clamp(20px, 3vw, 48px) 40px`（為浮動頂欄留空）
- 儀表板更「編輯式」：內容最大寬 **1120px** 置中；hero 大標 `clamp(44px, 6.2vw, 80px)`、字重 700、字距 `-0.035em`；背景有極淡格線（72px）與頂部綠色 wash（只在有活流量時出現）
- 斷點：手機 768px、平板 1024px

IP 管理系統若走「很好看的產品後台」，跟 EasyCLI 的左欄＋白畫布即可，不必複製 Management Center 那種超大 hero 與格線 wash；若要做一頁「系統健康總覽」，可酌情借用後者的大標與狀態句點。

---

## 5. 字體排印

### 5.1 Management Center（`src/styles/variables.scss`、`reset.scss`）

- 無下載網型。內文：

  `-apple-system, BlinkMacSystemFont, 'Segoe UI', 'Roboto', 'Oxygen', 'Ubuntu', 'Cantarell', 'Fira Sans', 'Droid Sans', 'Helvetica Neue', sans-serif`

- 等寬（IP、埠號、時間、YAML 應用）：

  `ui-monospace, 'SF Mono', 'Cascadia Mono', 'JetBrains Mono', 'Fira Code', Menlo, Consolas, 'Liberation Mono', monospace`

- 基本行高 1.5；`antialiased`
- 常見字級：表頭 12px、表格／表單 13px、按鈕與部分標籤 14px、卡片／對話／Sheet 標題 18px、側欄品牌 15px、側欄項 13px、群組標 10px、徽章 10.5–13px
- 按鈕字重 600；卡片標題 700
- 儀表板數字可用 `font-variant-numeric: tabular-nums`，hero 副文用等寬 13px

### 5.2 EasyCLIProxyAPI（`src/styles.css`、`src/styles/tokens/base.css`）

字級 token（請直接採用）：

| Token | 大小 | 用途 |
| --- | --- | --- |
| `--font-size-caption` | 12px | 輔助、圖例、小徽章 |
| `--font-size-meta` | 13px | 元資料、等寬路徑／URL |
| `--font-size-label` / `--font-size-body` | 14px | 標籤與內文 |
| `--font-size-section` | 16px | 小節標題 |
| `--font-size-panel-title` | 18px | 卡片標題 |
| `--font-size-dialog-title` | 20px | 對話標題 |
| `--font-size-page-title` | 24px | 頁標題 |
| `--font-size-display` | 28px | KPI 大數字（首頁成功率等會再加大） |

字重：400 regular、500 medium、600 semibold。標題與 `strong` 用 600，不是 800。

行高：`--line-height-tight: 1.35`、`--line-height-body: 1.6`、`--line-height-relaxed: 1.7`。`letter-spacing: 0`。

字族依語言切換（**未在 `index.html` 載入網型**，依本機／系統字體備援）：

- 預設（簡中）：`'Noto Sans SC', 'Noto Sans CJK SC', 'Source Han Sans SC', 'PingFang SC', 'Microsoft YaHei UI', 'Microsoft YaHei', system-ui, sans-serif`
- **繁中 `zh-TW`（IP 系統應使用這組）：** `'Noto Sans TC', 'Noto Sans CJK TC', 'Source Han Sans TC', 'PingFang TC', 'Microsoft JhengHei UI', 'Microsoft JhengHei', system-ui, sans-serif`
- 英文：`'Inter', 'Segoe UI Variable Text', 'Segoe UI', -apple-system, BlinkMacSystemFont, 'Noto Sans', 'Noto Sans SC', sans-serif`
- 等寬：`'Cascadia Code', 'SFMono-Regular', Consolas, 'Liberation Mono', monospace`

IP、MAC、CIDR、VLAN、埠號、最後同步時間一律用等寬，並啟用表格數字（tabular nums）。

---

## 6. 元件風格

以下尺寸若未另註，Management Center 來自 `src/styles/components.scss` 與 `src/components/ui/*`；EasyCLI 對齊官方截圖與 token。IP 系統以 EasyCLI 的「白底、細邊、淡陰影、近黑主按鈕」為準，圓角與間距兩套官方專案一致，可共用。

### 6.1 按鈕

- 圓角 **8px**（`$radius-md`）；全寬膠囊僅用於 Management Center 儀表板主行動（`$radius-full`）
- 預設內距 `10px 14px`，小尺寸 `8px 10px` / 14px 字
- 字重 600，圖示與文字間距 8px
- **主按鈕（EasyCLI 預設淺色）：** 背景與邊框 `#222222`，白字；這是截圖裡「+ 新增 API Key」的樣子
- **主按鈕（Management Center）：** 背景 `#8b8680`，白字
- **次要按鈕：** 淺底＋淡邊框；懸停略加深邊框
- **Ghost：** 透明，懸停才出現淺底
- **柔和危險（建議用於「停止同步／解除綁定」）：** 底 `#fff1f2`、邊 `#fecdd3`、字 `#e11d48`（如截圖「停止」）
- **實心危險：** `#c65746` 或 `#9f2d20` 底、白字，只用於不可逆刪除的確認
- 停用：透明度 0.6
- 圖示按鈕：方形或微圓角，線條圖示，刪除常用紅框線圖示鈕

### 6.2 卡片

- 背景為 surface／白；**1px 實線邊框**；圓角 **12px**（`$radius-lg`）
- 陰影極弱（`--shadow` 或 `--shadow-panel`），靠邊框分層，不要重陰影
- 內距 24px（`$spacing-lg`）；標題 18px / 700 或 600
- KPI 卡：上方小標籤、中間大數字、下方一行說明；可在底部加細進度條（成功綠、中性棕／灰）
- 狀態卡內用兩欄「標籤／值」清單，值可加狀態圓點

### 6.3 表格

來源：Management Center `Table.module.scss`（EasyCLI 列表頁在截圖中較常改用「列卡」，但表格 token 可直接沿用）。

- 外層 1px 邊框、圓角 8px、overflow hidden、卡片底
- 表頭底為 muted（淺灰／暖灰），文字 12px、字重 500、次要色；儲存格 `10px 14px`
- 正文 13px，儲存格 `12px 14px`，列底部分割線
- 列懸停：`accent-bg` 50% 混合；選中列：主色 8% 透明底
- 最後一列不分隔線
- 避免斑馬紋；不要粗邊框網格

### 6.4 表單

- 輸入框：寬 100%、1px 邊框、圓角 8px、內距 `10px 12px`、背景用頁面色（略別於卡片）
- 焦點：邊框改主色／`#222222`，外圈 `0 0 0 3px` 約 12–18% 透明的主色（Management Center 為 `rgba(#8b8680, 0.18)`）
- 標籤字重 600；提示 13px 次要色
- Select 高 40px（小尺寸 28px／12px 字）；下拉面板圓角 12px、內距 6px、最大高 240px
- 開關：軌道高 24px 全圓，拇指 18px（Management Center `ToggleSwitch`）
- 搜尋欄：左放大鏡、圓角 8px、淡邊框，常與右側按鈕組成工具列

### 6.5 徽章、膠囊、狀態

- 狀態徽章：全圓，內距 `4px 10px`，13px，細邊框＋淺底（成功／警告／錯誤／muted）
- 計數膠囊：12px，中性底
- 成功膠囊（EasyCLI）：底 `#f0fdf4`、字 `#15803d`、邊 `#bbf7d0`
- 狀態圓點：成功 `#10b981`，外圈淡光 `0 0 0 3px rgba(16, 185, 129, 0.2)`
- 導覽計數：側欄小圓角徽章
- 「執行中／可連線／本地採集中」這類即時狀態，用綠點或綠膠囊，放在卡片或頁首右上

### 6.6 圖示、對話、抽屜

- 圖示庫：**Lucide**，直線、圓角線帽、`stroke-width: 2`，預設 16–20px（頂欄 16px，側欄 18px）
- 不要用填色重量圖示或 Emoji 當主要圖示
- Modal：圓角 12px、大陰影；標題 18px
- Management Center 另有右側 **Sheet**（詳情／編輯），標題 18px、說明 13px、內距 24px
- 空狀態：淡底圓形圖示容器＋短說明，圓角 12px
- 捲軸：8px 寬，圓點拇指，軌道同頁面背景

### 6.7 圖表（來源：使用記錄官方截圖＋ `--usage-tone-*`）

- 堆疊直條、甜甜圈、細進度條；網格線極淡
- 系列色用藍 `#007aff`、紫 `#5856d6`、綠 `#34c759`、橙 `#ff9500` 這一組系統色，避免彩虹盤
- 圖例 12–13px，數字等寬

---

## 7. 互動模式

從原始碼與官方截圖歸納，IP 系統應對齊這些行為：

1. **側欄是主要導航**，選中項為淺色／白色膠囊；可收合為圖示軌，並提供鍵盤快捷鍵（Management Center 有側欄快捷鍵工具函式）。
2. **頁內分層：** 頁籤（總覽／明細）→ 篩選膠囊列 → 內容，而不是把篩選塞進舊式搜尋列後方的一排小按鈕。
3. **主行動靠右、實心深色；** 次要行動（重新整理、匯出）用線框或淺底；破壞性行動先用柔和危險，確認後才用實心紅。
4. **即時狀態要看得見：** 綠點「同步中／執行中」、頁首膠囊顯示最後同步筆數或時間；失敗用赤陶紅徽章，不要只靠 toast。
5. **設定類變更：** Management Center 用浮動儲存列＋存檔前 diff 預覽。IP 系統的批次變更（保留／釋放／衝突處理）可沿用「先預覽再套用」。
6. **詳情用右側 Sheet 或中型對話**，不要整頁跳走為唯一路徑。
7. **動效克制：** 懸停約 200ms、按下 160ms，曲線 `cubic-bezier(0.23, 1, 0.32, 1)` 或 `cubic-bezier(0.16, 1, 0.3, 1)`；按下縮放約 `0.97`。超過 300ms 的裝飾動效不要做。尊重 `prefers-reduced-motion`。
8. **主題與語言放在側欄底部或浮動頂欄**，提供淺色／深色／跟隨系統；可加「暖沙／紙感」作為第二淺色。
9. **通知：** 右上或頂部 toast，成功／警告／錯誤對應語意色；衝突事件除 toast 外，導覽上要有計數徽章。
10. **連線與驗證失敗要說人話**（可重試、可展開細節），對齊 EasyCLI 首頁「狀態讀不到時提供重試與可展開錯誤」的做法。

---

## 8. 套用到 IP 管理系統畫面

下列對照是為了把「CLI Proxy API 的樣子」落到具體頁面，而不是複製它的業務功能。

### 8.1 IP 列表（主列表）

對齊截圖：`easycliproxyapi-02-api-providers.png` 的工具列＋列卡，以及 Management Center 表格 token。

- 左欄導覽設「IP 位址」為選中膠囊
- 頂部：搜尋（IP／MAC／主機名）＋篩選膠囊（子網、交換器、狀態：在線／離線／衝突／未納管）＋右上實心近黑按鈕「新增保留／匯入」
- 表格 13px、表頭 12px；IP、MAC 用等寬；狀態用膠囊（在線＝成功綠、離線＝muted、衝突＝赤陶紅／危險膠囊）
- 列懸停淺底；列尾提供圖示鈕（複製 IP、編輯保留、解除）與可選開關（例如「鎖定／保留」）
- 密度維持「舒適」：列內距約 12px 上下，不要做成傳統網管的 28px 高密表

### 8.2 子網檢視

對齊截圖：`easycliproxyapi-01-home-dashboard.png` 的指標卡，以及 `easycliproxyapi-03-usage-analytics.png` 的使用率圖。

- 每個子網一張 12px 圓角卡片：CIDR（等寬標題）、說明、已用／可用／保留數字
- 卡片底部一條細使用率進度條：正常用成功綠，偏高用琥珀 `#d97706` / `#c77b30`，將滿或重疊用 `#c65746` / `#9f2d20`
- 可在右側或下鑽頁放甜甜圈（已用／保留／可用），系列色沿用分析頁系統色，不要另造一套
- 點進子網後，右側 Sheet 或下層頁顯示該網段 IP 列表，篩選列仍用膠囊下拉

### 8.3 交換器／ARP 同步狀態

對齊截圖：首頁「執行控制」卡（安裝狀態、執行狀態、版本、埠號、停止／重啟）。

- 一張（或每台交換器一張）狀態卡：交換器名稱、管理 IP（等寬）、連線狀態綠點、最後 ARP 同步時間（等寬）、本輪學習到的筆數、失敗原因
- 主操作：柔和危險「停止同步」、次要「立即同步／重試」
- 頁首或儀表板 KPI 列顯示：受管交換器數、最後同步是否成功、今日新增 IP、衝突數
- 同步進行中用細進度或「同步中」綠膠囊，失敗用失敗徽章＋可展開日誌，不要用全螢幕 blocker

### 8.4 衝突警示

對齊：失敗徽章、導覽計數、使用記錄裡「成功 301／失敗 7」的對比數字，以及柔和／實心危險按鈕層級。

- 儀表板 KPI 中「衝突」用危險色數字，其他指標保持近黑或系統色
- 側欄「衝突」項顯示紅／赤陶計數徽章
- 衝突列表欄位：IP、兩個（或多個）MAC、來源交換器／埠、首次／最近發現時間、處理狀態
- 列狀態膠囊：未處理＝危險、處理中＝琥珀、已解消＝成功
- 批次處理放在底部或頂部浮動列（對齊 Management Center 浮動儲存列），套用前預覽將變更的保留／註記
- 即時新衝突：toast ＋列表插入，同時更新徽章，不要只彈一次就消失

### 8.5 全域外殼建議（直接可寫進 PRD）

- 預設主題：EasyCLI **light**（白工作區、側欄 `#f7f8fa`、主色 `#222222`）
- 可選：深色（EasyCLI `dark` token）與暖沙／紙感（`warmSand` 或 Management Center `:root`）
- 介面語言優先繁中，字族用 Noto Sans TC／PingFang TC／微軟正黑體鏈
- 圖示：Lucide 線標
- 不要使用高飽和品牌藍作為全域主色；藍、紫、橙只出現在圖表與少數語意數字上
- 成功綠留給「在線、同步成功、已解消」；不要拿來畫裝飾背景，除非是極淡的健康狀態 wash

---

## 9. 官方截圖

Management Center 官方倉庫沒有介面截圖。下列三張均複製自 EasyCLIProxyAPI 官方 README 的簡中截圖（`docs/screenshots/zh-CN/`），授權隨上游 MIT。

| 檔案 | 原檔 | 畫面 | 對 IP 系統最有用的點 |
| --- | --- | --- | --- |
| `easycliproxyapi-01-home-dashboard.png` | `zh-CN/1.png` | 首頁儀表板 | 側欄、KPI 列、狀態卡、柔和危險鈕、協定分段控制 |
| `easycliproxyapi-02-api-providers.png` | `zh-CN/3.png` | API 接入列表 | 分類頁籤、搜尋工具列、近黑主按鈕、列卡、開關與徽章 |
| `easycliproxyapi-03-usage-analytics.png` | `zh-CN/4.png` | 使用記錄總覽 | 頁籤、篩選膠囊、彩色 KPI、長條圖＋甜甜圈、摘要小卡 |

路徑（本機）：

- `/workspace/specs/ip-mgmt/ui-ref/easycliproxyapi-01-home-dashboard.png`
- `/workspace/specs/ip-mgmt/ui-ref/easycliproxyapi-02-api-providers.png`
- `/workspace/specs/ip-mgmt/ui-ref/easycliproxyapi-03-usage-analytics.png`

上游位置：

- https://github.com/router-for-me/EasyCLIProxyAPI/blob/main/docs/screenshots/zh-CN/1.png
- https://github.com/router-for-me/EasyCLIProxyAPI/blob/main/docs/screenshots/zh-CN/3.png
- https://github.com/router-for-me/EasyCLIProxyAPI/blob/main/docs/screenshots/zh-CN/4.png

---

## 10. 給實作與 PRD 的檢查清單

- [ ] 左固定側欄約 264px，選中項為白（或淺）膠囊，不是藍條
- [ ] 工作區預設純白，卡片 12px 圓角、1px 淡邊框、極淡陰影
- [ ] 主色為 `#222222`（淺色主題），不是通用後台藍
- [ ] 成功 `#2f6b3f`／圓點 `#10b981`，警告 `#c77b30`，危險 `#9f2d20` 或 `#c65746`，勿混用
- [ ] 內文 14px、表格 13px、表頭 12px；IP／MAC／CIDR 等寬
- [ ] 繁中使用 Noto Sans TC／PingFang TC 鏈；圖示用 Lucide
- [ ] 主按鈕實心近黑、破壞性操作先柔和粉紅再實心紅
- [ ] 提供淺色／深色（可加暖沙）；動效 ≤ 300ms，並尊重減少動態
- [ ] IP 列表、子網、ARP 同步、衝突四頁皆能在本文件第 8 節找到對應元件

---

## 11. 原始碼索引（方便設計 Bot 對照）

- Management Center 主題：`src/styles/themes.scss`、`src/styles/variables.scss`
- Management Center 元件：`src/styles/components.scss`、`src/styles/layout.scss`、`src/components/ui/Table/Table.module.scss`
- Management Center 主題狀態：`src/stores/useThemeStore.ts`（`light` | `white` | `dark` | `auto`）
- Management Center 圖示：`src/components/ui/icons.tsx`
- EasyCLI 語意色與字級：`src/styles/tokens/semantic.css`、`src/styles/tokens/base.css`、`src/styles.css`
- EasyCLI 主題定義：`src/themes/light.ts`、`dark.ts`、`warmSand.ts`、`registry.ts`
